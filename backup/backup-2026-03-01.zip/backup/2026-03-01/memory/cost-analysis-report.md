# OpenClaw 成本分析报告

生成时间: 2026/3/1 17:28:30

## 📊 总览

- 总会话数: 3
- 总输入 tokens: 16,456,463
- 总输出 tokens: 43,461
- 总成本: $50.02
- 平均每会话: $16.674

## 🤖 模型使用统计

### MiniMax-M2.5
- 会话数: 3
- 输入: 16,456,463 tokens
- 输出: 43,461 tokens
- 成本: $50.02

## 💰 高成本会话 (Top 5)

- Session: ea1a8524...
  - 模型: MiniMax-M2.5
  - Tokens: 13,470,764
  - 成本: $40.65
  - 消息数: 185

- Session: ac749b0d...
  - 模型: MiniMax-M2.5
  - Tokens: 1,541,807
  - 成本: $4.81
  - 消息数: 138

- Session: 4ee06249...
  - 模型: MiniMax-M2.5
  - Tokens: 1,487,353
  - 成本: $4.55
  - 消息数: 92

## 💡 优化建议

### 1. 🔴 Context 过大

**问题**: 平均每次会话输入 5485488 tokens，可能加载了过多文件

**建议**: 优化 AGENTS.md、SOUL.md，移除不必要的内容；使用 lazy loading

**预计节省**: $20.01

**操作**: `参考 openclaw-token-optimizer skill 的 context_optimizer`

### 2. 🟡 长对话检测

**问题**: 发现 3 个长对话，最长 13,470,764 tokens

**建议**: 超过 50k tokens 时开启新会话，避免 context 累积

**预计节省**: $12.20

**操作**: `手动开启新会话或设置 context 限制`

### 3. 🟢 启用本地模型

**问题**: 简单任务可使用本地 Ollama 模型，完全免费

**建议**: 文件读取、简单查询等使用 local/qwen2.5:7b

**预计节省**: $0.50+

**操作**: `openclaw models set local/qwen2.5:7b (临时切换)`

**总预计节省**: $32.71